TableFilter is a set of Swing components to support user-driven filtering on table.

Full documentation is included in the home page at http://coderazzi.net/tablefilter

It works on Java 5 and later, but, due to missing functionality in Java 5, there is a version specific for Java 5, available at https://bitbucket.org/coderazzi/tablefilter-swing.java5

A discussion group exists at http://groups.google.com/group/tablefilter-swing ; any member can join it and receive update notifications, or start / participate on any discussion

The output (binaries) can be used directly in maven, as they are hosted in the central repository at http://repo2.maven.org/maven2/net/coderazzi/